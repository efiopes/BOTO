import random
def joke():
    list = ["On a Facebook page for beginning artists, one asked, “Any suggestions for painting dogs?” Another responded,  “Wait till they’re asleep.”",
            "Q: Why did the pig have ink all over its face? A: Because it came out of the pen.",
            "My paramedic team was called to an emergency. Before we took the patient to the hospital, I had a question for his wife."
            " “Does your husband have any cardiac problems?” I asked.“Yes,” she said with a note of concern. “His cardiologist just died.”",
            "Spotted in the classifieds: “For sale: cemetery plot, $200, so I don’t have to spend all eternity beside my ex!”",
            "An Uber is cruising down a boulevard when it runs a red light. “Hey!” the passenger shouts. “Be careful!” “Don’t worry,” says the driver."
            " “My brother does it all the…",
            "The four most beautiful words in our common language: I told you so.",
            "Never trust math teachers who use graph paper. They’re always plotting something."]
    x = random.randint(0, len(list)-1)
    return  list[x]
