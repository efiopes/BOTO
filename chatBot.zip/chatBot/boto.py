
from bottle import route, run, template, static_file, request
import json
import time
from datetime import date
import calendar
from jokes import joke
import random


def should_do(list):
    new_list = list.split()
    print(new_list)
    options = ['do', "now", 'choose', 'take', 'call', 'who', 'think', 'actions', 'next', "be", "answer", "solution"]
    for j in new_list:
        if j in options:
            return "Think about it few minutes - you will find the way ..."


def get_season():
    """
    convert date to month and day as integer (md) ---- 4/21 = 421, 11/17 = 1117
    """
    x = time.localtime()
    m = x.tm_mon * 100
    d = x.tm_mday
    md = m + d

    if (md > 300) and (md <= 331) or (md > 400) and (md <= 430) or (md > 500) and (md <= 531):
        s = 'spring'
    elif (md > 600) and (md <= 630) or (md > 700) and (md <= 731) or (md > 800) and (md <= 831):
        s = 'summer'
    elif (md > 900) and (md <= 930) or (md > 1000) and (md <= 1031) or (md > 1100) and (md <= 1130):
        s = 'autumn'
    elif (md > 1200) and (md <= 1231) or (md > 100) and (md <= 131) or (md > 200) and (md <= 229):
        s = 'winter'
    else:
        raise IndexError("Invalid date")

    return s


def get_weather():
    weather_now = get_season()
    if weather_now == "spring":
        return "mostly shining"
    elif weather_now == "winter":
        return "sometimes raining, but mostly is shining"
    elif weather_now == "summer":
        return "is HOT out there"
    elif weather_now == "autumn":
        return "mostly shining"
    else:
        return "need to ckeck"


def time_now():
    x = time.localtime()
    current_time = f'{x.tm_hour} : {x.tm_min} : {x.tm_sec}'
    return current_time


def day_today():
    my_date = date.today()
    today = calendar.day_name[my_date.weekday()]
    return today


def date_today():
    x = time.localtime()
    today_date = f'{x.tm_mday} : {x.tm_mon} : {x.tm_year}'
    return today_date


def answer_question(msg):
    print(msg)
    if 'time' in msg:
        x = time_now()
        print(x)
        return 'now time is ' + x, "excited"
    elif 'date' in msg:
        x = date_today()
        print(x)
        return 'today date is ' + x, "excited"
    elif 'today' in msg:
        x = day_today()
        print(x)
        return 'today is ' + x, "excited"
    elif "season" in msg:
        return get_season(), "ok"
    elif "weather" in msg:
        return get_weather(), "ok"
    elif "should" in msg:
        return should_do(msg), "ok"
    elif 'advice' in msg:
        return 'I am not so good to give advices ', "ok"
    elif ('doing' or 'do') and 'I' in msg and 'should' not in msg:
        return "I don't know. Maybe ask your Mom", "giggling"
    elif ('doing' or 'do') and 'how' in msg:
        return 'fine! How are you?', "dancing"
    elif ('are' or 'you') and 'how' in msg:
        return 'fine! How are you?', "dancing"
    elif ('doing' or 'do') and ('what' in msg) and ('should' not in msg):
        return 'what you mean? - helping you', "dancing"
    elif 'think' or 'thinking' in msg:
        return 'yea think so', "dancing"
    elif 'planning' in msg:
        return 'not yet', "dancing"
    elif 'plan' in msg:
        return 'yes, good one, secret', "dancing"
    elif 'idea' and "my" in msg:
        return 'go for it', "dancing"
    elif 'idea' and "I" in msg:
        return 'good for you', "dancing"
    elif 'help' in msg:
        return 'yes - I"ll help you', "ok"

    elif 'you' and "idea" in msg:
        return 'no for now, maybe later', "dancing"
    else:
        return "need to check"



def check_swear(list):
    swear = ['fuck','shit', 'piss off','ass','insane', 'fool', 'asshole','bitch', 'bastard', 'damn', 'god', 'stupid','hell','evil','fuck off', 'fuck you']
    for i in list:
        if i in swear:
            return "its not appropriate", "no"
        else:
            return None


def last_word(list):
    list = list.split()
    last = ['opinion', 'think so', 'guess', 'suppose', 'nothing', 'left']
    b = [i for i in list if i in last]
    if b:
        return "Probably you right", "ok"
    else:
        return "nice", "ok"


def first_word(list):
    first = ['want', 'think', 'like', 'would', 'thinking', 'suppose', 'guess', 'looking', "suggest"]
    for i in list:
        if i in first:
            return "its ok, go ahead", "no"
    if "worry" in list:
        return "dont worry, it will be ok", "dog"
    elif "worrying" in list:
        return "don't worry, it will be ok", "dog"
    elif "sick" in list or ("feel" in list and "bad" in list):
        return "take care - go see a doctor", "dog"
    elif "upset" in list:
        return "don't worry, it will be ok", "dog"
    elif "name" in list or "am" in list:
        return say_hi(list)
    else:
        return None


def user_statement(list):
    list = list.split()
    req = ['hurry up',"hurry", 'fast', 'faster', 'emergency', 'important', 'dangerous', 'late', 'lost',"go","answer", "do it"]
    for j in list:
        if j in req:
            return "no panic, no hurry", "ok"
        else:
            return None


def say_hi(list):
        name = ''
        names = ['my', 'name', 'is', 'I', 'am','first name', 'last name', "it is", "it's", "here"]
        for j in list:
            if j not in names:
                name += j
        return f"Nice to meet you {name} how can I help you? ", " ok "


def byebye():
    return "bye bye, I was glad to help you?", " takeoff "


def handle_user_msg(message):

    message_list = message.split(" ")
    if check_swear(message_list):# ok
        return check_swear(message_list)
    elif message.startswith('I'):# ok
        return first_word(message_list)

    elif ("tell" in message or "give" in message) and "joke" in message:
        return joke(), "laughing"
    elif "hello" in message or "hi" in message:  # ok
        return "hello you too", "money"
    elif "bye" in message:
        return byebye()
    elif "sad" in message or "feel bad" in message or "not happy" in message:
        return "everything will be ok", "crying"
    elif "boring" in message:
        return "go do some fun", "ok"
    elif "ok" in message or "fine" in message:
        return "awesome", "ok"
    elif "stop" in message:
        return "ok", "ok"
    elif "happy" in message or "having fun" in message or "enjoying" in message:
        return "good for you", "inlove"
    elif message.endswith('?'):# ok
        return answer_question(message.replace("?", ""))
    elif message.endswith('!'):
        return user_statement(message.replace("!", ""))
    elif "kill" in message_list:
        return "I am calling the police", "afraid"
    elif "not" in message_list and ("good" in message_list or "smart" in message_list):
        return "May be you right", "heartbroke"
    elif "nice" in message_list:
        return "Yeeea", "dancing"
    elif "good" in message_list:
        return "That's right", "dancing"
    elif "fantastic" in message_list:
        return "Unbelievable!", "dancing"
    elif "awesome" in message_list:
        return "Fantastic", "dancing"
    elif "unbelievable" in message_list:
        return "Fantastic", "dancing"
    elif "thank" in message_list:
        return "you are welcome", "inlove"
    elif "morning" in message_list:
        return "Good Morning", "dancing"
    elif "evening" in message_list:
        return "Good Evening", "dancing"
    elif "night" in message_list:
        return "Good Night", "dancing"
    elif "day" in message_list:
        return "Nice day", "dancing"
    elif "have a good day" in message_list:
        return "you too", "dancing"
    elif "not understand" in message_list:
        return "can you explain", "confused"
    elif "help" in message_list:
        return "sure I help you", "ok"
    elif "advice" in message_list:
        return "I am not sure I am good advicer", "ok"

    elif message.endswith(''):
        return last_word(message)

    elif message.endswith('.') or message.endswith(' .'):#!!!!!!!!!!!!
        return last_word(message.replace(".", ""))

    else:
        return 'pls be more explicit', "no"


@route('/', method='GET')
def index():
    return template("chatbot.html")


@route("/chat", method='POST')
def chat():
    user_message = request.POST.get('msg')
    print(handle_user_msg(user_message))
    msg, animation = handle_user_msg(user_message)
    return json.dumps({"animation": animation, "msg": msg})


@route("/test", method='POST')
def chat():
    user_message = request.POST.get('msg')
    user_message = handle_user_msg(user_message)
    return json.dumps({"animation": "waiting", "msg": user_message})


@route('/js/<filename:re:.*\.js>', method='GET')
def javascripts(filename):
    return static_file(filename, root='js')


@route('/css/<filename:re:.*\.css>', method='GET')
def stylesheets(filename):
    return static_file(filename, root='css')


@route('/images/<filename:re:.*\.(jpg|png|gif|ico)>', method='GET')
def images(filename):
    return static_file(filename, root='images')


def main():
    run(host='localhost', port=7000, reloader=True)


if __name__ == '__main__':
    main()
